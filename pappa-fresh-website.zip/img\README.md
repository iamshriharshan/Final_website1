Pappa Fresh Images

Place product and site images in this folder. Suggested filenames:

- equino.png — Equino (Horse) product image
- manzo.png — Manzo (Beef) product image
- pollo.png — Pollo (Chicken) product image
- tacchino.png — Tacchino (Turkey) product image
- maiale.png — Maiale (Pork) product image

Notes:
- Keep dimensions reasonable for web (e.g., 800–1200px on the long side) and use optimized PNG/JPG/WebP.
- After adding files, ensure the file names match those referenced in js/data.js.

